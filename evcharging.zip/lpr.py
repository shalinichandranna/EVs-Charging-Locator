import requests
from pprint import pprint
##regions = ["mx", "us-ca"] # Change to your country
with open('img.jpg', 'rb') as fp:
    response = requests.post(
        'https://api.platerecognizer.com/v1/plate-reader/',
        files=dict(upload=fp),
        headers={'Authorization': 'Token 2ccadab5c77204a1ee32afd0498ce48b9a9e50cd'})
results = response.json()
pprint(results['results'][0]['plate'])
