from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import sqlite3
import secrets
import random
import telepot
import threading
import time
connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

command = """CREATE TABLE IF NOT EXISTS user(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, password TEXT, mobile TEXT, email TEXT, numberplate TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, mobile TEXT, email TEXT, numberplate TEXT, slot TEXT, booked time, entry TEXT, exit TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, mobile TEXT, numberplate TEXT, slot TEXT, entry TEXT, exit TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS feedback( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, feed TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS wallet(balance TEXT, numberplate TEXT)"""
cursor.execute(command)

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

def Check():
    while True:
        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        cursor.execute("select * from history where entry is null")
        result = cursor.fetchall()
        print(result)
        if result:
            for row in result:
                booked = row[6]
                print('booked time', booked)
                from datetime import datetime
                now = datetime.now()
                Time = now.strftime("%H:%M")
                print("current Time:", Time)

                booked_time = datetime.strptime(booked, "%H:%M")
                current_time = datetime.strptime(Time, "%H:%M")

                time_difference = current_time - booked_time
                difference_in_minutes = time_difference.total_seconds() / 60
                difference_in_minutes = int(difference_in_minutes)
                print(f"Time difference: {difference_in_minutes} minutes")

                if difference_in_minutes > 10:
                    print("your evcharging booking cancled due to absense")
                    cursor.execute("delete from history where numberplate = '"+row[4]+"'")
                    connection.commit()
                    bot = telepot.Bot("7893178034:AAEd4n_30PzclSF2_ZH5SkqiFVZwRCm9CjQ")
                    bot.sendMessage('6866415345', str("your evcharging booking cancled due to absense"))

        time.sleep(1)

@app.route('/')
def index():
    # t1 = threading.Thread(target=Check)
    # t1.start()
    return render_template('index.html')
 
@app.route('/home')
def home():
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()

    cursor.execute("select slot from history where exit is null")
    result = cursor.fetchall()

    slots = []
    for slot in result:
        slots.append(slot[0])
    print(slots)
    return render_template('station.html', slots=slots)

@app.route('/main')
def main():
    return render_template('index.html')

@app.route('/map')
def map():
    return render_template('home.html')

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()
    query = "SELECT * FROM feedback"
    cursor.execute(query)
    result = cursor.fetchall()
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        feed = request.form['feed']

        cursor.execute("INSERT INTO feedback VALUES (NULL, '"+name+"', '"+email+"', '"+feed+"')")
        connection.commit()

        query = "SELECT * FROM feedback"
        cursor.execute(query)
        result = cursor.fetchall()

        return render_template('feedback.html', result=result)
    return render_template('feedback.html', result=result)

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        numberplate = request.form['numberplate']
        password = request.form['password']

        query = "SELECT * FROM user WHERE numberplate = '"+numberplate+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchone()

        if result:
            session['numberplate'] = numberplate
            return render_template('home.html')
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')

    return render_template('signin.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        numberplate = request.form['numberplate']
        
        print(name, mobile, email, password, numberplate)

        query = "SELECT * FROM user WHERE numberplate = '"+numberplate+"'"
        cursor.execute(query)
        result = cursor.fetchone()

        if result:
            return render_template('signin.html', msg='This numberplate already exists')

        cursor.execute("INSERT INTO user VALUES (NULL, '"+name+"', '"+password+"', '"+mobile+"', '"+email+"', '"+numberplate+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('signup.html')

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        numberplate = request.form['numberplate']
        
        print(name, mobile, email, password)
        cursor.execute("update user set password=?, mobile = ?, email = ?, name = ? where numberplate = ?", [password, mobile, email, name, session['numberplate']])
        connection.commit()

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()
        cursor.execute("select * from user where numberplate = '"+session['numberplate']+"'")
        result = cursor.fetchone()
        return render_template('index.html', msg='profile updated successfully')
    
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()
    cursor.execute("select * from user where numberplate = '"+session['numberplate']+"'")
    result = cursor.fetchone()
    return render_template('profile.html', result=result)

@app.route('/get_data')
def get_data():
   from serial_test import read_data
   Data1 = read_data()
   print("recieved data {}".format(Data1))
   return jsonify(Data1)

@app.route('/recharge', methods=['GET', 'POST'])
def recharge():
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()
    numberplate = session['numberplate']

    if request.method == 'POST':
        amount = int(request.form['amount'])

        cursor.execute("select balance from wallet where numberplate = '"+numberplate+"'")
        result = cursor.fetchone()
        if result:
            print(result[0])
            amount += int(result[0])
            cursor.execute("update wallet set balance = '"+str(amount)+"'")
            connection.commit()
        else:
            cursor.execute("INSERT INTO wallet VALUES ('"+str(amount)+"', '"+numberplate+"')")
            connection.commit()

        cursor.execute("select * from wallet where numberplate = '"+numberplate+"'")
        result=cursor.fetchone()

        if result:
            balance = result[0]
        else:
            balance = 0
        
        # bot = telepot.Bot("7893178034:AAEd4n_30PzclSF2_ZH5SkqiFVZwRCm9CjQ")
        # bot.sendMessage('6866415345', str(f"Recharge successfull. Available balance is Rs. {balance}"))

        return render_template('recharge.html',balance=balance)
    
    cursor.execute("select * from wallet where numberplate = '"+numberplate+"'")
    result=cursor.fetchone()

    if result:
        balance = result[0]
    else:
        balance = 0
    return render_template('recharge.html',balance=balance)

@app.route('/history')
def history():
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()

    cursor.execute("select * from history where numberplate = '"+session['numberplate']+"'")
    result = cursor.fetchall()
    print(result)
    if result:
        return render_template('history.html', result=result)
    else:
        return render_template('history.html', msg="history not found")

@app.route('/signout')
def signout():
    return render_template('index.html')

@app.route('/book/<slot>')
def book(slot):
    print(slot)
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()

    cursor.execute("select name, mobile, email, numberplate from user where numberplate = '"+session['numberplate']+"'")
    result = list(cursor.fetchone())
    result.append(slot)
    
    from datetime import datetime
    now = datetime.now()
    Time = now.strftime("%H:%M")
    print("Booked Time:", Time)

    result.append(Time)
    print(result)

    cursor.execute("insert into history (name, mobile, email, numberplate, slot, booked) values (?,?,?,?,?,?)", result)
    connection.commit()

    bot = telepot.Bot("7893178034:AAEd4n_30PzclSF2_ZH5SkqiFVZwRCm9CjQ")
    # bot.sendMessage('6866415345', str(f"EV charging slot booked successfully. Slot code is {slot}"))
    # bot.sendLocation('6866415345', latitude=12.73144017431866, longitude=77.27295927964556)

    slots = []
    for slot in result:
        slots.append(slot[0])
    print(slots)
    return render_template('station.html', msg = 'Booked successfully', slots=slots)

if __name__ == "__main__":
    app.run(debug=True)
