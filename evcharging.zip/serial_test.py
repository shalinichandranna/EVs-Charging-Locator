import serial
import time
import requests
import telepot
import sqlite3
connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

command = """CREATE TABLE IF NOT EXISTS user(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, password TEXT, mobile TEXT, email TEXT, numberplate TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, mobile TEXT, email TEXT, numberplate TEXT, slot TEXT, booked time, entry TEXT, exit TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, mobile TEXT, numberplate TEXT, slot TEXT, entry TEXT, exit TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS feedback( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, feed TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS wallet(balance TEXT, numberplate TEXT)"""
cursor.execute(command)

data = serial.Serial(
                  'COM3',
                  baudrate = 9600,
                  parity=serial.PARITY_NONE,
                  stopbits=serial.STOPBITS_ONE,
                  bytesize=serial.EIGHTBITS,                  
                  timeout=1
                  )

import sqlite3

connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

print('waiting for vehicle')
while True:
    d = data.readline()
    d = d.decode('UTF-8', 'ignore')
    d = d.strip()
    if d:
        print(d)
        if d == 'Entry':
            print("Entry.........")
            import cv2
            vs = cv2.VideoCapture(0)
            while True:
                ret,  img = vs.read()
                if not ret:
                    print("camera not recognised")
                    break
                cv2.imshow('srtream', img)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    cv2.imwrite('frame.png', img)
                    break
            vs.release()
            cv2.destroyAllWindows()

            try:
                with open('frame.png', 'rb') as fp:
                    response = requests.post(
                        'https://api.platerecognizer.com/v1/plate-reader/',
                        files=dict(upload=fp),
                        headers={'Authorization': 'Token 81dda232b51e3f7c7620f0830834a6d8c94e0120'})
                results = response.json()
                number = results['results'][0]['plate'].upper()
                print(number)

                cursor.execute("select * from history where numberplate = '"+number+"' and entry is null")
                result = cursor.fetchone()
                print(result)
                if result:
                    from datetime import datetime
                    now = datetime.now()
                    Time = now.strftime("%H:%M")
                    print("Entry Time:", Time)
                    cursor.execute("update history set entry = '"+Time+"' where numberplate = '"+number+"'")
                    connection.commit()

                    slot = result[5]
                    print('slot ', slot)
                    data.write(str.encode(slot))
                    # bot = telepot.Bot("7893178034:AAEd4n_30PzclSF2_ZH5SkqiFVZwRCm9CjQ")
                    # bot.sendMessage('6866415345', str(f"Your vehicle entered to ev charging slot code {slot}  at {Time}"))

                else:
                    name = str(input('Enter name '))
                    mobile = str(input('Enter mobile '))
                    slot = str(input('Enter slot '))
                    from datetime import datetime
                    now = datetime.now()
                    Time = now.strftime("%H:%M")
                    print("Entry Time:", Time)
                    data = [name, mobile, number, slot, Time]
                    cursor.execute("insert into records (name, mobile, numberplate, slot, entry) values (?,?,?,?,?)", data)
                    connection.commit()
                    print('slot ', slot)
                    data.write(str.encode(slot))
                    # bot = telepot.Bot("7893178034:AAEd4n_30PzclSF2_ZH5SkqiFVZwRCm9CjQ")
                    # bot.sendMessage('6866415345', str("This numberplate does not have account. Create your account in www.evcharging.com"))
            except Exception as e:
                print(e)
                print('numberplate not recognised')
        

        if d == 'Exit':
            print("Exit..........")
            import cv2
            vs = cv2.VideoCapture(0)
            while True:
                ret,  img = vs.read()
                if not ret:
                    print("camera not recognised")
                    break
                cv2.imshow('srtream', img)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    cv2.imwrite('frame.png', img)
                    break
            vs.release()
            cv2.destroyAllWindows()

            try:
                with open('frame.png', 'rb') as fp:
                    response = requests.post(
                        'https://api.platerecognizer.com/v1/plate-reader/',
                        files=dict(upload=fp),
                        headers={'Authorization': 'Token 81dda232b51e3f7c7620f0830834a6d8c94e0120'})
                results = response.json()
                number = results['results'][0]['plate'].upper()
                print(number)

                cursor.execute("select * from history where numberplate = '"+number+"' and exit is null")
                result1 = cursor.fetchone()
                print(result1)
                if result1:
                    cursor.execute("select * from wallet where numberplate = '"+number+"'")
                    result = cursor.fetchone()

                    if result:
                        Balance = int(result[0])
                        if Balance < 100:
                            print('insufficient balance')
                            data.write(str.encode('E'))
                            # bot = telepot.Bot("7893178034:AAEd4n_30PzclSF2_ZH5SkqiFVZwRCm9CjQ")
                            # bot.sendMessage('6866415345', str(f"insufficient balance please recharge. availabale balance is Rs. {Balance}"))
                        else:
                            av_balance = Balance - 100
                            cursor.execute("update wallet set balance = '"+str(av_balance)+"' where numberplate = '"+number+"'")
                            connection.commit()
                            print('amount deducted')
                            from datetime import datetime
                            now = datetime.now()
                            Time = now.strftime("%H:%M")
                            print("Exit Time:", Time)
                            cursor.execute("update history set exit = '"+Time+"' where numberplate = '"+number+"'")
                            connection.commit()
                            slt = result1[5]
                            data.write(str.encode(slt))
                            # bot = telepot.Bot("7893178034:AAEd4n_30PzclSF2_ZH5SkqiFVZwRCm9CjQ")
                            # bot.sendMessage('6866415345', str(f"Your vehicle exit from ev charging slot code {slt}  at {Time}. Rs. 100 deducted from your wallet and available balance is {av_balance}"))
                    else:
                        print('insufficient balance')
                        data.write(str.encode('E'))
                else:
                    cursor.execute("select * from records where numberplate = '"+number+"' and exit is null")
                    result = cursor.fetchone()
                    print(result)
                    if result:
                        from datetime import datetime
                        now = datetime.now()
                        Time = now.strftime("%H:%M")
                        print("Exit Time:", Time)
                        cursor.execute("update records set exit = '"+Time+"' where numberplate = '"+number+"'")
                        connection.commit()
                        slt = result[4]
                        data.write(str.encode(slt))
                        # bot = telepot.Bot("7893178034:AAEd4n_30PzclSF2_ZH5SkqiFVZwRCm9CjQ")
                        # bot.sendMessage('6866415345', str(f"Your vehicle exit from ev charging slot code {slt}  at {Time}. Rs. 100 deducted from your wallet and available balance is {av_balance}"))
                    else:
                        print('invalid numberplate')
            except Exception as e:
                print(e)
                print('numberplate not recognised')
    time.sleep(1)
